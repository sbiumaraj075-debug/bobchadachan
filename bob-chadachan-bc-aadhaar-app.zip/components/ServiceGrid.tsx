
import React from 'react';
import { TRANSLATIONS, COLORS } from '../constants';
import { ServiceType } from '../types';

interface ServiceGridProps {
  onSelectService: (type: ServiceType) => void;
}

const services = [
  { type: ServiceType.CASH_WITHDRAWAL, icon: '🏧', label: TRANSLATIONS.CASH_WITHDRAWAL },
  { type: ServiceType.BALANCE_INQUIRY, icon: '🔍', label: TRANSLATIONS.BALANCE_INQUIRY },
  { type: ServiceType.MINI_STATEMENT, icon: '📄', label: TRANSLATIONS.MINI_STATEMENT },
  { type: ServiceType.AADHAAR_PAY, icon: '🆔', label: TRANSLATIONS.AADHAAR_PAY },
  { type: ServiceType.DEPOSIT, icon: '💰', label: TRANSLATIONS.DEPOSIT },
];

const ServiceGrid: React.FC<ServiceGridProps> = ({ onSelectService }) => {
  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4 p-4">
      {services.map((service) => (
        <button
          key={service.type}
          onClick={() => onSelectService(service.type)}
          className="bg-white p-6 rounded-2xl shadow-sm hover:shadow-md transition-all flex flex-col items-center gap-3 border border-gray-100 hover:border-orange-300 group"
        >
          <span className="text-4xl group-hover:scale-110 transition-transform">{service.icon}</span>
          <span className="text-sm font-bold text-gray-700 text-center">{service.label}</span>
        </button>
      ))}
    </div>
  );
};

export default ServiceGrid;
