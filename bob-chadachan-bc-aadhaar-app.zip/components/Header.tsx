
import React from 'react';
import { TRANSLATIONS, COLORS } from '../constants';

const Header: React.FC = () => {
  return (
    <header 
      className="p-4 shadow-lg text-white flex justify-between items-center sticky top-0 z-50"
      style={{ backgroundColor: COLORS.BOB_BLUE }}
    >
      <div className="flex items-center gap-3">
        <div 
          className="w-10 h-10 rounded-full flex items-center justify-center font-bold text-xl"
          style={{ backgroundColor: COLORS.BOB_ORANGE }}
        >
          B
        </div>
        <div>
          <h1 className="text-lg md:text-xl font-bold">{TRANSLATIONS.APP_TITLE}</h1>
          <p className="text-xs opacity-80">{TRANSLATIONS.CHADACHAN_BRANCH}</p>
        </div>
      </div>
      <div className="text-right hidden sm:block">
        <p className="text-sm font-semibold">Agent ID: BOB_CHA_045</p>
        <p className="text-[10px] text-orange-200">Terminal: AEPS-V3</p>
      </div>
    </header>
  );
};

export default Header;
