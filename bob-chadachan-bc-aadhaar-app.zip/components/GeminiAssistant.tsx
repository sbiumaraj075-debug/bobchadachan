
import React, { useState } from 'react';
import { TRANSLATIONS, COLORS } from '../constants';
import { askBankingQuestion } from '../services/geminiService';

const GeminiAssistant: React.FC = () => {
  const [query, setQuery] = useState('');
  const [response, setResponse] = useState('');
  const [loading, setLoading] = useState(false);

  const handleAsk = async () => {
    if (!query.trim()) return;
    setLoading(true);
    const result = await askBankingQuestion(query);
    setResponse(result);
    setLoading(false);
  };

  return (
    <div className="bg-orange-50 border border-orange-200 rounded-2xl p-6 mb-6">
      <div className="flex items-center gap-2 mb-4">
        <span className="text-2xl">✨</span>
        <h3 className="font-bold text-orange-800">{TRANSLATIONS.GEMINI_INSIGHTS}</h3>
      </div>
      
      <div className="flex gap-2 mb-4">
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder={TRANSLATIONS.ASK_GEMINI}
          className="flex-1 p-3 rounded-xl border border-orange-300 focus:outline-none focus:ring-2 focus:ring-orange-500"
        />
        <button
          onClick={handleAsk}
          disabled={loading}
          className="bg-orange-600 text-white px-6 py-3 rounded-xl font-bold hover:bg-orange-700 transition-all disabled:opacity-50"
        >
          {loading ? '...' : 'ಕೇಳಿ'}
        </button>
      </div>

      {response && (
        <div className="bg-white p-4 rounded-xl border border-orange-100 text-gray-700 animate-fade-in text-sm leading-relaxed whitespace-pre-wrap">
          {response}
        </div>
      )}
    </div>
  );
};

export default GeminiAssistant;
