
import React, { useState } from 'react';
import { TRANSLATIONS, COLORS } from '../constants';
import { ServiceType } from '../types';

interface TransactionFormProps {
  serviceType: ServiceType;
  onSubmit: (data: { aadhaar: string; amount: number }) => void;
  onCancel: () => void;
}

const TransactionForm: React.FC<TransactionFormProps> = ({ serviceType, onSubmit, onCancel }) => {
  const [aadhaar, setAadhaar] = useState('');
  const [amount, setAmount] = useState('');
  const [isScanning, setIsScanning] = useState(false);

  const needsAmount = [ServiceType.CASH_WITHDRAWAL, ServiceType.DEPOSIT, ServiceType.AADHAAR_PAY].includes(serviceType);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsScanning(true);
    // Simulate biometric scan
    setTimeout(() => {
      onSubmit({ aadhaar, amount: Number(amount) || 0 });
      setIsScanning(false);
    }, 2000);
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-[100]">
      <div className="bg-white rounded-3xl w-full max-w-md p-6 shadow-2xl">
        <h2 className="text-2xl font-bold mb-6 text-gray-800" style={{ color: COLORS.BOB_BLUE }}>
          {TRANSLATIONS[serviceType]}
        </h2>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">{TRANSLATIONS.AADHAAR_NUMBER}</label>
            <input
              type="text"
              maxLength={12}
              required
              className="w-full p-4 border border-gray-300 rounded-xl text-lg tracking-widest focus:ring-2 focus:ring-orange-500 outline-none"
              placeholder="0000 0000 0000"
              value={aadhaar}
              onChange={(e) => setAadhaar(e.target.value.replace(/\D/g, ''))}
            />
          </div>

          {needsAmount && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">{TRANSLATIONS.ENTER_AMOUNT}</label>
              <input
                type="number"
                required
                className="w-full p-4 border border-gray-300 rounded-xl text-lg focus:ring-2 focus:ring-orange-500 outline-none"
                placeholder="₹ 0.00"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
              />
            </div>
          )}

          <div className="pt-4 flex flex-col gap-3">
            <button
              type="submit"
              disabled={isScanning}
              className="w-full p-4 rounded-xl text-white font-bold text-lg transition-all flex items-center justify-center gap-2"
              style={{ backgroundColor: COLORS.BOB_ORANGE }}
            >
              {isScanning ? (
                <>
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  {TRANSLATIONS.SCAN_FINGERPRINT}...
                </>
              ) : (
                TRANSLATIONS.PROCEED
              )}
            </button>
            <button
              type="button"
              onClick={onCancel}
              className="w-full p-4 rounded-xl text-gray-500 font-medium hover:bg-gray-100 transition-all"
            >
              {TRANSLATIONS.CANCEL}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default TransactionForm;
