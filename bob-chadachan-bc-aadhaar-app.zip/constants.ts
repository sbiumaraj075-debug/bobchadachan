
import { Localization } from './types';

export const COLORS = {
  BOB_ORANGE: '#F47920',
  BOB_BLUE: '#003366',
};

export const TRANSLATIONS: Localization = {
  APP_TITLE: 'ಬ್ಯಾಂಕ್ ಆಫ್ ಬರೋಡಾ ಚಡಚಣ BC',
  WELCOME: 'ಸ್ವಾಗತ, ಚಡಚಣ BC ಏಜೆಂಟ್',
  CASH_WITHDRAWAL: 'ನಗದು ಹಿಂಪಡೆಯುವಿಕೆ',
  BALANCE_INQUIRY: 'ಬ್ಯಾಲೆನ್ಸ್ ವಿಚಾರಣೆ',
  MINI_STATEMENT: 'ಮಿನಿ ಸ್ಟೇಟ್ಮೆಂಟ್',
  AADHAAR_PAY: 'ಆಧಾರ್ ಪೇ',
  DEPOSIT: 'ನಗದು ಠೇವಣಿ',
  AADHAAR_NUMBER: 'ಆಧಾರ್ ಸಂಖ್ಯೆ',
  ENTER_AMOUNT: 'ಮೊತ್ತವನ್ನು ನಮೂದಿಸಿ',
  PROCEED: 'ಮುಂದುವರಿಯಿರಿ',
  CANCEL: 'ರದ್ದುಗೊಳಿಸಿ',
  TRANSACTION_HISTORY: 'ವಹಿವಾಟಿನ ಇತಿಹಾಸ',
  GEMINI_INSIGHTS: 'AI ವರದಿ ಮತ್ತು ಸಹಾಯ',
  SCAN_FINGERPRINT: 'ಬೆರಳಚ್ಚು ಸ್ಕ್ಯಾನ್ ಮಾಡಿ',
  SUCCESS: 'ಯಶಸ್ವಿಯಾಗಿದೆ',
  FAILED: 'ವಿಫಲವಾಗಿದೆ',
  RECENT_ACTIVITY: 'ಇತ್ತೀಚಿನ ಚಟುವಟಿಕೆ',
  CHADACHAN_BRANCH: 'ಚಡಚಣ ಶಾಖೆ',
  ASK_GEMINI: 'ಬ್ಯಾಂಕಿಂಗ್ ಬಗ್ಗೆ ಪ್ರಶ್ನೆ ಕೇಳಿ...',
};
