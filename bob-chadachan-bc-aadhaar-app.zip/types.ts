
export enum ServiceType {
  CASH_WITHDRAWAL = 'CASH_WITHDRAWAL',
  BALANCE_INQUIRY = 'BALANCE_INQUIRY',
  MINI_STATEMENT = 'MINI_STATEMENT',
  AADHAAR_PAY = 'AADHAAR_PAY',
  DEPOSIT = 'DEPOSIT'
}

export interface Transaction {
  id: string;
  type: ServiceType;
  amount: number;
  aadhaarNumber: string;
  timestamp: Date;
  status: 'SUCCESS' | 'FAILED' | 'PENDING';
  customerName?: string;
}

export interface Localization {
  [key: string]: string;
}
