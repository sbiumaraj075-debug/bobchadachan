
import { GoogleGenAI, Type } from "@google/genai";
import { Transaction } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const getTransactionAnalysis = async (transactions: Transaction[]) => {
  const prompt = `Analyze these Bank of Baroda BC transactions and provide a summary in Kannada. 
  Focus on total volume, success rate, and any suspicious patterns. 
  Transactions: ${JSON.stringify(transactions)}`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        systemInstruction: "You are a professional banking assistant for Bank of Baroda BC agents in Karnataka. You speak fluent Kannada and English. Provide helpful, accurate summaries of daily transaction reports.",
      }
    });
    return response.text;
  } catch (error) {
    console.error("Gemini Analysis Error:", error);
    return "ವಿಶ್ಲೇಷಣೆ ಲಭ್ಯವಿಲ್ಲ. (Analysis unavailable)";
  }
};

export const askBankingQuestion = async (question: string) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: question,
      config: {
        systemInstruction: "You are an expert in Aadhaar Enabled Payment Systems (AEPS) and Bank of Baroda procedures. Answer questions in Kannada clearly for a BC agent.",
      }
    });
    return response.text;
  } catch (error) {
    console.error("Gemini Question Error:", error);
    return "ಕ್ಷಮಿಸಿ, ಉತ್ತರಿಸಲು ಸಾಧ್ಯವಾಗುತ್ತಿಲ್ಲ. (Sorry, unable to answer)";
  }
};
